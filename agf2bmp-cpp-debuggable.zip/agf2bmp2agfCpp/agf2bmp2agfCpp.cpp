// agf2png.cpp, v1.01 2008/06/13
// coded by asmodean

// contact: 
//   web:   http://plaza.rakuten.co.jp/asmodean
//   email: asmodean [at] hush.com
//   irc:   asmodean on efnet (irc.efnet.net)

// This tool converts AGF images to bitmaps.
#include <io.h>
#include <direct.h>
#include <sys/stat.h>
#include <string.h>
#include <windows.h>
#include "agf2bmp2agfCpp.h"
#include <string>
#include <stdio.h>
#include <fcntl.h>
#include <iostream>
#include <fstream>
#include "lzss.h"
typedef std::string string;
typedef int FileId;

static const unsigned long AGF_TYPE_24BIT = 1;
static const unsigned long AGF_TYPE_32BIT = 2;

struct AGFHDR {
	unsigned char signature[4]; // "", "ACGF"
	unsigned long type;
	unsigned long unknown;
};

struct ACIFHDR {
	unsigned char signature[4]; // "ACIF"
	unsigned long type;
	unsigned long unknown;
	unsigned long original_length;
	unsigned long width;
	unsigned long height;
};

struct AGFSECTHDR {
	unsigned long original_length;
	unsigned long original_length2; // why?
	unsigned long length;
};
namespace as
{
	int open_or_die(const string& filename, int flags, int mode) {
		int fd = _open(filename.c_str(), flags, mode);

		if (fd == -1) {
			fprintf(stderr, "Could not open %s (%s)\n", filename.c_str(), strerror(errno));
			exit(-1);
		}
		return fd;
	}
	string get_file_prefix(string in_filename) {
		return "C:\\Users\\Gusty\\Documents\\Visual Studio 2017\\Projects\\EushullyUtilities\\AGF2BMP2AGF\\bin\\Debug\\out";
	}
	void write_bmp_ex(string  out_filename,
		unsigned char* buff,
		unsigned long len,
		unsigned long width,
		unsigned long height,
		unsigned long byteCount,
		unsigned long clrUsed,
		RGBQUAD* pal) {

	}

	int write_bmp(const string& filename,
		unsigned char* buff,
		unsigned long    len,
		unsigned long    width,
		unsigned long    height,
		unsigned short   depth_bytes)
	{
		int i = 0;
		while (true) {
			if (buff[i] != 0) 
			{
				break;
			}
			i++;
		}
		unsigned char a0 = buff[0];
		unsigned char a1 = buff[1];
		unsigned char a2 = buff[2];
		unsigned char a3 = buff[3];
		unsigned char a4 = buff[4];
		unsigned char a5 = buff[5];
		unsigned char a6 = buff[6];
		unsigned char a7 = buff[7];
		BITMAPFILEHEADER bmf;
		BITMAPINFOHEADER bmi;

		memset(&bmf, 0, sizeof(bmf));
		memset(&bmi, 0, sizeof(bmi));

		bmf.bfType = 0x4D42;
		bmf.bfSize = sizeof(bmf) + sizeof(bmi) + len;
		bmf.bfOffBits = sizeof(bmf) + sizeof(bmi);

		bmi.biSize = sizeof(bmi);
		bmi.biWidth = width;
		bmi.biHeight = height;
		bmi.biPlanes = 1;
		bmi.biBitCount = depth_bytes * 8;

		int fd = open_or_die(filename + ".bmp",
			O_CREAT | O_TRUNC | O_WRONLY | O_BINARY,
			S_IREAD | S_IWRITE);
		_write(fd, &bmf, sizeof(bmf));
		_write(fd, &bmi, sizeof(bmi));
		_write(fd, buff, len);
		return _close(fd);
	}
}
/*
void read(FileId fd, void* hdr, unsigned long size)
{
	char* buff = new char[size];
	fd->read(buff, size);
	memcpy(hdr, buff, size);
}*/
void read_sect(FileId fd, unsigned char*& out_buff, unsigned long& out_len) {
	AGFSECTHDR hdr;
	_read(fd, &hdr, sizeof(hdr));

	unsigned long  len = hdr.length;
	unsigned char* buff = new unsigned char[len];
	_read(fd, buff, len);

	out_len = hdr.original_length;
	out_buff = new unsigned char[out_len];

	if (len == out_len) {
		memcpy(out_buff, buff, out_len);
	}
	else {
		unlzss(buff, len, out_buff, out_len);
	}

	delete[] buff;
}

int main(int argc, char** argv) {
	if (argc < 2) {
		fprintf(stderr, "agf2png v1.01 by asmodean\n\n");
		fprintf(stderr, "usage: %s <input.agf> [output.bmp]\n", argv[0]);
		return -1;
	}

	string in_filename(argv[1]);
	string out_filename = as::get_file_prefix(in_filename) + ".bmp";

	if (argc > 2) {
		out_filename = argv[2];
	}

	FileId fd = as::open_or_die(in_filename, O_RDONLY | O_BINARY, 0);

	AGFHDR hdr;
	_read(fd, &hdr, sizeof(hdr));
	if (hdr.type != AGF_TYPE_24BIT && hdr.type != AGF_TYPE_32BIT) {
		fprintf(stderr, "%s: unsupported type (might be MPEG)\n", in_filename.c_str());
		return 0;
	}

	//here so good so far
	unsigned long  bmphdr_len = 0;
	unsigned char* bmphdr_buff = NULL;
	read_sect(fd, bmphdr_buff, bmphdr_len);

	unsigned long  len = 0;
	unsigned char* buff = NULL;
	read_sect(fd, buff, len);

	// Notice there's a gap of 2 bytes between these... alignment I guess.
	BITMAPFILEHEADER* bmf = (BITMAPFILEHEADER*)bmphdr_buff;
	BITMAPINFOHEADER* bmi = (BITMAPINFOHEADER*)(bmphdr_buff + 16);
	RGBQUAD* pal = (RGBQUAD*)(bmi + 1);

	if (hdr.type == AGF_TYPE_32BIT) {
		ACIFHDR acifhdr;
		_read(fd, &acifhdr, sizeof(acifhdr));

		unsigned long  alpha_len = 0;
		unsigned char* alpha_buff = NULL;
		read_sect(fd, alpha_buff, alpha_len);
		unsigned long  rgba_len = bmi->biWidth * bmi->biHeight * 4;
		unsigned char* rgba_buff = new unsigned char[rgba_len];

		unsigned long  rgb_stride = (bmi->biWidth * bmi->biBitCount / 8 + 3) & ~3;

		for (long y = 0; y < bmi->biHeight; y++) {
			unsigned char* rgb_line = buff + y * rgb_stride;
			unsigned char* alp_line = alpha_buff + (bmi->biHeight - y - 1) * bmi->biWidth;
			unsigned char* rgba_line = rgba_buff + y * bmi->biWidth * 4;

			for (long x = 0; x < bmi->biWidth; x++) {
				if (bmi->biBitCount == 8) {
					char val = rgba_line[x * 4 + 0] = pal[rgb_line[x]].rgbBlue;
					rgba_line[x * 4 + 1] = pal[rgb_line[x]].rgbGreen;
					rgba_line[x * 4 + 2] = pal[rgb_line[x]].rgbRed;
				}
				else {
					rgba_line[x * 4 + 0] = rgb_line[x * 3 + 0];
					rgba_line[x * 4 + 1] = rgb_line[x * 3 + 1];
					rgba_line[x * 4 + 2] = rgb_line[x * 3 + 2];
				}
				char alpha = rgba_line[x * 4 + 3] = alp_line[x];
			}
		}

		as::write_bmp(out_filename,
			rgba_buff,
			rgba_len,
			bmi->biWidth,
			bmi->biHeight,
			4);

		delete[] rgba_buff;
		delete[] alpha_buff;
	}
	else {
		as::write_bmp_ex(out_filename,
			buff,
			len,
			bmi->biWidth,
			bmi->biHeight,
			bmi->biBitCount / 8,
			bmi->biClrUsed,
			pal);
	}

	delete[] buff;
	delete[] bmphdr_buff;

	//close(fd);

	return 0;
}
