#include <stdio.h>
#include <stdlib.h>
#ifndef EXAPI
#define EXAPI  extern "C" __declspec(dllexport) 
#endif
int lzss(unsigned char*, int, unsigned char*, int);
int unlzss(unsigned char*, int, unsigned char*, int);
EXAPI int __stdcall unlzss2(unsigned char* inputbuf, unsigned char* outputbuf, int* inputlen, int* outputlen);
EXAPI int __stdcall unlzssTest();
