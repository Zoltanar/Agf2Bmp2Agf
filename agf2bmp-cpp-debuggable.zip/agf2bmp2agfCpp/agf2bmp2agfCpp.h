#pragma once

void read_sect(int fd, unsigned char*& out_buff, unsigned long& out_len);
